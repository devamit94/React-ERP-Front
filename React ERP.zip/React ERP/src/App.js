import './App.scss'
import './Assets/css/style.scss'

import { useEffect, useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Outlet } from "react-router-dom";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import Sidebar from './Dashboard/Layout/Sidebar';
import Main from './Dashboard/Pages/Main';
import Header from './Dashboard/Layout/Header';
import SaleOrder from './Dashboard/Pages/Sale-Order/SaleOrder';
import SaleOrderItem from './Dashboard/Pages/Sale-Order/SaleOrderItem';
import AverageSalePurchase from './Dashboard/Pages/AverageSalePurchase';
import PurchaseOrders from './Dashboard/Pages/Purchase-Orders/PurchaseOrders';
import PurchaseOrdersReports from './Dashboard/Pages/Purchase-Orders/PurchaseOrdersReports';
import PurchaseOrderItems from './Dashboard/Pages/Purchase-Orders/PurchaseOrderItems';
import POItemsReport from './Dashboard/Pages/Purchase-Orders/POItemsReport';
import RawMaterial from './Dashboard/Pages/Raw-stock/RawMaterial';
import RawMaterialSizes from './Dashboard/Pages/Raw-stock/RawMaterialSizes';
import RawMaterialReport from './Dashboard/Pages/Raw-stock/RawMaterialReport';
import ReturnReport from './Dashboard/Pages/Raw-stock/ReturnReport';
import FinishMaterial from './Dashboard/Pages/Finished-Stock/FinishMaterial';
import FinishedMaterialReports from './Dashboard/Pages/Finished-Stock/FinishedMaterialReports';
import FinishedMaterialSizes from './Dashboard/Pages/Finished-Stock/FinishedMaterialSizes';
import FinishedMaterialGrade from './Dashboard/Pages/Finished-Stock/FinishedMaterialGrade';
import RawStockBill from './Dashboard/Pages/Raw-stock/RawStockBill';
import Parties from './Dashboard/Pages/Contacts/Parties';
import Brokers from './Dashboard/Pages/Contacts/Brokers';
import AllVehicles from './Dashboard/Pages/AllVehicles';
import Users from './Dashboard/Pages/ERP-Users/Users';
import IpList from './Dashboard/Pages/ERP-Users/IpList';
import UsersAdd from './Dashboard/Pages/ERP-Users/UsersAdd';
import Product from './Dashboard/Pages/Manage-Product/Product';
import AddSaleOrder from './Dashboard/Pages/Sale-Order/AddSaleOrder';
import RawMaterialAdd from './Dashboard/Pages/Raw-stock/RawMaterialAdd';
import FinishMaterialAdd from './Dashboard/Pages/Finished-Stock/FinishMaterialAdd';
import AddParty from './Dashboard/Pages/Contacts/AddParty';
import AddBroker from './Dashboard/Pages/Contacts/AddBroker';
import Size from './Dashboard/Pages/Manage-Product/Size';
import Grades from './Dashboard/Pages/Manage-Product/Grades';
import Login from './Dashboard/Auth/Login';
import Brand from './Dashboard/Pages/Manage-Product/Brand';
import AddSize from './Dashboard/Pages/Manage-Product/AddSize';

function App() {
  const toggleBtn = () => {
    document.body.classList.toggle('new-dashboard');
  }



  const Dashboard = () => {
    return (
      <>
        <Header toggle={toggleBtn} />
        <Sidebar />
        <Outlet />

      </>
    )
  }

  const Auth = () => {
    return (
      <>
        <Outlet />
      </>
    )
  }
  return (
    <>
      
      <Router>
      <ToastContainer />
        <Routes>


          <Route element={<Auth />}>
            <Route path='/login' element={<Login />} />
          </Route>
          <Route element={<Dashboard />}>
            <Route path='/' element={<Main />} />
            <Route path='/sale-Order' element={<SaleOrder />} />
            <Route path='/sale-order-items' element={<SaleOrderItem />} />
            <Route path='/add-sale-order' element={<AddSaleOrder />} />
            <Route path='/average-sale-purchase' element={<AverageSalePurchase />} />
            <Route path='/purchase-orders' element={<PurchaseOrders />} />
            <Route path='/purchase-orders-reports' element={<PurchaseOrdersReports />} />
            <Route path='/purchase-orders-item' element={<PurchaseOrderItems />} />
            <Route path='/purchase-orders-item-reports' element={<POItemsReport />} />
            <Route path='/raw-material' element={<RawMaterial />} />
            <Route path='/raw-material-add' element={<RawMaterialAdd />} />
            <Route path='/raw-material-sizes' element={<RawMaterialSizes />} />
            <Route path='/raw-material-size-report' element={<RawMaterialReport />} />
            <Route path='/raw-material-return-report' element={<ReturnReport />} />
            <Route path='/finish-material' element={<FinishMaterial />} />
            <Route path='/finish-material-add' element={<FinishMaterialAdd />} />
            <Route path='/finished-material-reports' element={<FinishedMaterialReports />} />
            <Route path='/finish-material-sizes' element={<FinishedMaterialSizes />} />
            <Route path='/finish-material-grade' element={<FinishedMaterialGrade />} />
            <Route path='/rawstock-bill' element={<RawStockBill />} />
            <Route path='/parties' element={<Parties />} />
            <Route path='/add-party' element={<AddParty />} />
            <Route path='/add-brokers' element={<AddBroker />} />
            <Route path='/brokers' element={<Brokers />} />
            <Route path='/all-vehicles' element={<AllVehicles />} />
            <Route path='/all-users' element={<Users />} />
            <Route path='/product' element={<Product />} />
            <Route path='/brand' element={<Brand />} />
            <Route path='/size' element={<Size />} />
            <Route path='/add-size' element={<AddSize />} />
            <Route path='/grades' element={<Grades />} />
            <Route path='/add-users' element={<UsersAdd />} />
            <Route path='/ip-list' element={<IpList />} />



          </Route>
        </Routes>
        
      </Router>



    </>
  );
}

export default App;
