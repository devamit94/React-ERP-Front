import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
// import toast from 'react-hot-toast';
import { AdminLoginApi } from "../../Apis/AuthApi";




export const AdminLogin = createAsyncThunk("AdminLogin", async (data) => {
    try {
        const response = await AdminLoginApi(data);
            console.log('authslice response',response);
            
        // if (response.status === 200) {
        //     toast.success("OTP Send Succesfully");
        //     return response.data
        // } else {
        //     toast.error("error");
        // }
    } catch (error) {
        throw error;
    }
});



























// create reducer and action
export const AuthSlice = createSlice({
    name: "AuthSlice",
    initialState: {
        adminlogin: [],
        loading: false,
        error: null
    },
    extraReducers: (builder) => {
        // Admin Login
        builder.addCase(AdminLogin.pending, (state) => {
            state.loading = true;
        })
            .addCase(AdminLogin.fulfilled, (state, action) => {
                state.loading = false;
                state.adminlogin = action.payload;
            })
            .addCase(AdminLogin.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            })

            
    }
});

export default AuthSlice.reducer;