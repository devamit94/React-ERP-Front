
import { commonrequest } from "./Commonrequest";



// admin register api
export const AdminLoginApi = async (data, header) => {
    return await commonrequest("POST", `https://aksteels.com/tradding/api/login.php`, data, header, "admin");
}