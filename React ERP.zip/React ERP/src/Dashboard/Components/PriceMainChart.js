import React, { useState } from 'react';
import ReactApexChart from 'react-apexcharts';

const PriceReportChart = () => {
    const [series] = useState([
        {
            name: 'SO Average Rate (Rs.)',
            data: [0.1, 0.5, 0.8, 0.3, 0.7, 1.0, 0.6] // Replace with actual SO average rates
        },
        {
            name: 'PO Average Rate (Rs.)',
            data: [0.2, 0.6, 0.9, 0.4, 0.8, 0.7, 0.9] // Replace with actual PO average rates
        }
    ]);

    const [options] = useState({
        chart: {
            type: 'line',
            height: 350,
            zoom: {
                enabled: true
            }
        },
        dataLabels: {
            enabled: false
        },
        stroke: {
            curve: 'smooth',
            width: 2
        },
        title: {
            text: 'Price Report',
            align: 'left',
            style: {
                fontSize: '16px', 
                fontWeight: 600, 
                color: '#333',  
                fontFamily: 'Poppins, sans-serif'
            }
        },
        xaxis: {
            type: 'datetime',
            categories: [
                '2024-01-01', '2024-01-02', '2024-01-03', '2024-01-04', '2024-01-05', '2024-01-06', '2024-01-07'
            ] // Replace with actual dates
        },
        yaxis: {
            title: {
                text: 'Average Rate (Rs.)'
            }
        },
        legend: {
            position: 'top',
            horizontalAlign: 'right'
        },
        colors: ['#FF4560', '#008FFB'], // Colors for the lines
        tooltip: {
            shared: true,
            y: {
                formatter: function(val) {
                    return `${val.toFixed(2)} Rs.`;
                }
            }
        }
    });

    return (
        <div>
            <ReactApexChart options={options} series={series} type="line" height={350} />
        </div>
    );
};

export default PriceReportChart;
