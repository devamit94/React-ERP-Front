import React, { useState } from 'react';
import ReactApexChart from 'react-apexcharts';

const OrderMainChart = () => {
    const [series] = useState([
        {
            name: 'Sale (MT)',
            data: [0.1, 0.2, 0.3, 0.25, 0.4, 0.3, 0.35, 0.4, 0.5] 
        },
        {
            name: 'Purchase (MT)',
            data: [0.15, 0.25, 0.2, 0.3, 0.35, 0.4, 0.45, 0.4, 0.5] 
        }
    ]);

    const [options] = useState({
        chart: {
            type: 'line',
            height: 350,
            zoom: {
                enabled: true
            }
        },
        dataLabels: {
            enabled: false
        },
        stroke: {
            curve: 'smooth',
            width: 2
        },
        title: {
            text: 'Order Report',
            align: 'left',
            style: {
                fontSize: '16px', 
                fontWeight: 600, 
                color: '#333',  
                fontFamily: 'Poppins, sans-serif'
            }
        },
        xaxis: {
            type: 'datetime',
            categories: [
                '2024-10-18', '2024-10-19', '2024-10-20', '2024-10-21', '2024-10-22', '2024-10-23', '2024-10-24', '2024-10-25', '2024-10-26'
            ] // Replace with actual dates
        },
        yaxis: {
            title: {
                text: 'Average Rate (MT)'
            }
        },
        legend: {
            position: 'top',
            horizontalAlign: 'right'
        },
        colors: ['#FF4560', '#008FFB'], // Colors for Sale (MT) and Purchase (MT)
        markers: {
            size: 5,
        },
        grid: {
            borderColor: '#f1f1f1'
        },
        tooltip: {
            shared: true,
            y: {
                formatter: function(val) {
                    return `${val.toFixed(2)} MT`;
                }
            }
        }
    });

    return (
        <div>
            <ReactApexChart options={options} series={series} type="line" height={350} />
        </div>
    );
};

export default OrderMainChart;
