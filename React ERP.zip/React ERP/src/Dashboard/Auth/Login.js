import React, { useState } from 'react'
import Logo from '../../Assets/img/logo.png'
import { FaRegEye, FaRegEyeSlash } from 'react-icons/fa'
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { AdminLogin } from '../../Redux/slice/AuthSlice';
import { toast } from 'react-toastify';

const Login = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [visible, setVisible] = useState(true);
    const [userName, setUserName] = useState();
    const [password, setPassword] = useState();
    const passToggle = () => {
        setVisible(!visible)

    }

    const handleAuthLogin = (e) => {
        e.preventDefault();

        if (userName === "") {
            toast.error("userName is required!");
            console.log('userName is required!');
        } else if (password === "") {
            toast.error('Password is required!');
            console.log('Password is required!');
        } else {
            let data = {
                username: userName,
                password: password
            };
            console.log('Data', data);

            dispatch(AdminLogin(data)).then((res) => {
                console.log('login-api-submit',res);
                
                if (res.payload) {
                    // navigate("/dashboard")

                }
            }).catch((error) => {
                console.log("Error:", error);
            });
        }
    };
    return (
        <>
            <section className='auth-wrapper' >
                <div className='auth-inner'>
                    <div className='auth-content'>
                        <div class="card">
                            <div class="card-body">
                                <div className='logo'>
                                    <img src={Logo} alt='auth-logo-image' />
                                    <h6>Welcome !</h6>
                                    <p>Please enter your username and password to sign in<br /> to your account</p>
                                </div>
                                <form onSubmit={handleAuthLogin}>
                                    <div className='form-group'>
                                        <label>Username</label>
                                        <input type="text" placeholder='Username' className='form-control' 
                                        onChange={(e) => setUserName(e.target.value)} value={userName}
                                        />

                                    </div>
                                    <div className='form-group'>
                                        <label>Password</label>
                                        <div class="input-group password-group">
                                            <input type={visible ? "password" : "text"} class="form-control" placeholder="Password" aria-label="Recipient's username" aria-describedby="button-addon2"
                                            onChange={(e) => setPassword(e.target.value)}  value={password}
                                            />
                                            <button class="btn btn-outline-secondary eye-btn" type="button" id="button-addon2" onClick={passToggle}>
                                                {visible ? <FaRegEye className='eye-icon' /> : <FaRegEyeSlash className="eye-icon" />}
                                            </button>
                                        </div>
                                    </div>
                                    <div className='form-group d-flex gap-1 align-items-center'>
                                        <input id="t&c" type="Checkbox" />
                                        <label for="t&c" className='mb-0'>Keep me logged in</label>

                                    </div>
                                    <div className='form-group d-flex gap-1 align-items-center mt-3 mb-3 '>
                                        <button type="submit" className='btn submit-btn1 common-btn'>Sign In</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </>
    )
}

export default Login