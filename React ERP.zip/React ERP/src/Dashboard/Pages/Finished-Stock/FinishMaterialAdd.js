import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { BsPrinter } from "react-icons/bs";
import Select from 'react-select';
import { IoMdSearch } from 'react-icons/io';

const options = [
    { value: 'chocolate', label: 'Chocolate' },
    { value: 'strawberry', label: 'Strawberry' },
    { value: 'vanilla', label: 'Vanilla' },
];

const FinishMaterialAdd = () => {
    const [selectedOption, setSelectedOption] = useState(null);
    return (
        <>
            <section id="main" className={`main`}>
                <div className='container-fluid'>
                    <div className='page-main-header'>
                        <div className='page-title'>
                            <h4>Finish Material Add</h4>
                        </div>

                        <div className='page-right'>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><Link to="/">Dashboard</Link></li>
                                    <li class="breadcrumb-item active" aria-current="page">Finish Material Add</li>
                                </ol>
                            </nav>
                        </div>
                    </div>


                    <div className='main-table mt-30'>
                        <div className='table-header'>
                            <div className='th-left'>
                            </div>
                            <div className='th-right'>
                                {/* <Link to="/" className='btn common-btn t-btn1'>+ Raw Material</Link> */}
                                <Link to="/finish-material" className='btn common-btn t-btn1'>View All</Link>
                                {/* <button className='btn common-btn t-btn2'><BsPrinter className='me-1' />Print</button> */}
                            </div>
                        </div>
                        <div className='table-form-row'>
                            <form className='row'>
                                <div className='form-group col-xxl-3 col-xl-3 col-md-4 col-sm-6'>
                                    <label>Product </label>
                                    <Select
                                        defaultValue={selectedOption}
                                        onChange={setSelectedOption}
                                        options={options}
                                    />
                                </div>
                                <div className='form-group col-xxl-3 col-xl-3 col-md-4 col-sm-6'>
                                    <label>Size </label>
                                    <Select
                                        defaultValue={selectedOption}
                                        onChange={setSelectedOption}
                                        options={options}
                                    />
                                </div>
                                <div className='form-group col-xxl-3 col-xl-3 col-md-4 col-sm-6'>
                                    <label>Grade</label>
                                    <Select
                                        defaultValue={selectedOption}
                                        onChange={setSelectedOption}
                                        options={options}
                                    />
                                </div>
                                <div className='form-group col-xxl-3 col-xl-3 col-md-4 col-sm-6'>
                                    <label> Heat No</label>
                                    <input type="text" placeholder="" className='form-control' />
                                </div>
                                <div class="form-group col-xxl-3 col-xl-3 col-md-4 col-sm-6">
                                    <label>Length</label>
                                    <div className='input-group'>
                                        <input type="number" class="form-control input1" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" />
                                        <div class="input-group-append">
                                            <select class="custom-select form-control select1">
                                                <option selected>Choose...</option>
                                                <option value="1">One</option>
                                                <option value="2">Two</option>
                                                <option value="3">Three</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div className='form-group col-xxl-3 col-xl-3 col-md-4 col-sm-6'>
                                    <label>Edge Type</label>
                                    <select class="custom-select form-control">
                                        <option selected>Choose...</option>
                                        <option value="1">One</option>
                                        <option value="2">Two</option>
                                        <option value="3">Three</option>
                                    </select>
                                </div>
                                
                                <div className='form-group col-xxl-3 col-xl-3 col-md-4 col-sm-6'>
                                    <label>Customer</label>
                                    <Select
                                        defaultValue={selectedOption}
                                        onChange={setSelectedOption}
                                        options={options}
                                    />
                                </div>
                                <div className='form-group col-xxl-3 col-xl-3 col-md-4 col-sm-6'>
                                    <label>Dead stock</label>
                                    <Select
                                        defaultValue={selectedOption}
                                        onChange={setSelectedOption}
                                        options={options}
                                    />
                                </div>
                                
                                <div className='col-12 '>
                                    <div className='form-group-1 mt-3'>
                                        <button type='button' className='btn form-control submit-btn1 common-btn'>Add To Raw Material</button>
                                    </div>
                                </div>


                            </form>
                        </div>


                    </div>
                </div>
            </section>

        </>
    )
}



export default FinishMaterialAdd