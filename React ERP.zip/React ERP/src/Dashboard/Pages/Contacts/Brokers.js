import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { BsPrinter } from "react-icons/bs";
import Select from 'react-select';
import { IoMdSearch } from 'react-icons/io';

const options = [
    { value: 'chocolate', label: 'Chocolate' },
    { value: 'strawberry', label: 'Strawberry' },
    { value: 'vanilla', label: 'Vanilla' },
];


const Brokers = () => {
    const [selectedOption, setSelectedOption] = useState(null);
    return (
        <>
            <section id="main" className={`main`}>
                <div className='container-fluid'>
                    <div className='page-main-header'>
                        <div className='page-title'>
                            <h4>All Brokers</h4>
                        </div>

                        <div className='page-right'>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><Link to="/">Dashboard</Link></li>
                                    <li class="breadcrumb-item active" aria-current="page">Brokers</li>
                                </ol>
                            </nav>
                        </div>
                    </div>


                    <div className='main-table mt-30'>
                        <div className='table-header'>
                            <div className='th-left'>
                            </div>
                            <div className='th-right'>
                                <Link to="/add-brokers" className='btn common-btn t-btn1'>+ New Broker</Link>
                                {/* <button className='btn common-btn t-btn2'><BsPrinter className='me-1' />Print</button> */}
                            </div>
                        </div>
                        <div className='table-form-row'>
                            <form className='row'>
                            <div className='form-group col-xxl-3 col-xl-3 col-sm-4'>
                                    <label>Brokers Name</label>
                                    <input type='text' placeholder='' className='form-control' />
                                </div>
                               
                                
                              
                                <div className='form-group col-md-auto col-sm-4 form-btn d-flex align-items-end'>
                                    <button type='button' className='btn form-control submit-btn common-btn'><IoMdSearch /></button>
                                </div>


                            </form>
                        </div>

                        <div className='table-main-row'>
                            
                            <div className='table-responsive'>
                                <table className='table table-striped table-bordered'>
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Broker Name</th>
                                            <th>Contact No</th>
                                            <th>Address</th>
                                            <th>City</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                           
                                            

                                        </tr>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            
                                           

                                        </tr>
                                        
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </>
    )
}

export default Brokers