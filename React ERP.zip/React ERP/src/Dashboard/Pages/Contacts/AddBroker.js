import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { BsPrinter } from "react-icons/bs";
import Select from 'react-select';
import { Country, State, City } from 'country-state-city';
import { IoMdSearch } from 'react-icons/io';

const options = [
    { value: 'chocolate', label: 'Chocolate' },
    { value: 'strawberry', label: 'Strawberry' },
    { value: 'vanilla', label: 'Vanilla' },
];

const AddBroker = () => {
    const [selectedOption, setSelectedOption] = useState(null);
    const [selectedState, setSelectedState] = useState('');
    const [selectedCity, setSelectedCity] = useState('');
    const [cities, setCities] = useState([]);

    const statesInIndia = State.getStatesOfCountry('IN');

    const handleStateChange = (event) => {
        const stateCode = event.target.value;
        setSelectedState(stateCode);
        const citiesInState = City.getCitiesOfState('IN', stateCode);
        setCities(citiesInState);
    };
    const handleCityChange = (event) => {
        setSelectedCity(event.target.value);
      };



    return (
        <>
            <section id="main" className={`main`}>
                <div className='container-fluid'>
                    <div className='page-main-header'>
                        <div className='page-title'>
                            <h4>Add New Broker</h4>
                        </div>

                        <div className='page-right'>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><Link to="/">Dashboard</Link></li>
                                    {/* <li class="breadcrumb-item active" aria-current="page">Parties</li> */}
                                </ol>
                            </nav>
                        </div>
                    </div>


                    <div className='main-table mt-30'>
                        <div className='table-header'>
                            <div className='th-left'>
                            </div>
                            <div className='th-right'>
                                <Link to="/brokers" className='btn common-btn t-btn1'>View All</Link>
                                {/* <button className='btn common-btn t-btn2'><BsPrinter className='me-1' />Print</button> */}
                            </div>
                        </div>
                        <div className='table-form-row'>
                            <form className='row'>
                                <div className='form-group col-xxl-3 col-xl-3 col-md-4 col-sm-6'>
                                    <label>Broker Name <span className='text-red'>*</span></label>
                                    <input type='text' placeholder='Broker Name' className='form-control' />
                                </div>
                                
                                <div className='form-group col-xxl-3 col-xl-3 col-md-4 col-sm-6'>
                                    <label>Contact No <span className='text-red'>*</span></label>
                                    <input type='text' placeholder='Contact No' className='form-control' />
                                </div>
                                
                                
                                <div className='form-group col-xxl-3 col-xl-3 col-md-4 col-sm-6'>
                                    <label>Address <span className='text-red'>*</span></label>
                                    <input type='text' placeholder='Address' className='form-control' />

                                </div>
                                <div className='form-group col-xxl-3 col-xl-3 col-md-4 col-sm-6'>
                                    <label>State <span className='text-red'>*</span></label>
                                    {/* <input type='text' placeholder='State' className='form-control' /> */}
                                    <select onChange={handleStateChange} className='form-control'>
                                        <option value=''>Select State</option>
                                        {statesInIndia.map((state) => (
                                            <option key={state.isoCode} value={state.isoCode}>
                                                {state.name}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <div className='form-group col-xxl-3 col-xl-3 col-md-4 col-sm-6'>
                                    <label>City <span className='text-red'>*</span></label>
                                    <select onChange={handleCityChange} className='form-control' value={selectedCity}>
                                        <option value=''>Select City</option>
                                        {cities.map((city) => (
                                            <option key={city.name} value={city.name}>
                                                {city.name}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <div className='form-group col-xxl-3 col-xl-3 col-md-4 col-sm-6'>
                                    <label>Pin Code <span className='text-red'>*</span></label>
                                    <input type='text' placeholder='Pin Code ' className='form-control' />
                                </div>
                                

                               

                                <div className='col-12 '>
                                    <div className='form-group-1 mt-3'>
                                        <button type='button' className='btn form-control submit-btn1 common-btn'>Submit</button>
                                    </div>
                                </div>




                            </form>
                        </div>


                    </div>
                </div>
            </section>

        </>
    )
}



export default AddBroker