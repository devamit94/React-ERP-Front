import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { BsPrinter } from "react-icons/bs";
import Select from 'react-select';
import { IoMdSearch } from 'react-icons/io';

const options = [
    { value: 'chocolate', label: 'Chocolate' },
    { value: 'strawberry', label: 'Strawberry' },
    { value: 'vanilla', label: 'Vanilla' },
];

const RawStockBill = () => {
    const [selectedOption, setSelectedOption] = useState(null);
    return (
        <>
            <section id="main" className={`main`}>
                <div className='container-fluid'>
                    <div className='page-main-header'>
                        <div className='page-title'>
                            <h4>Raw Material Bill</h4>
                        </div>

                        <div className='page-right'>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><Link to="/">Dashboard</Link></li>
                                    <li class="breadcrumb-item active" aria-current="page">Raw Material Bill</li>
                                </ol>
                            </nav>
                        </div>
                    </div>


                    <div className='main-table mt-30'>
                        <div className='table-header'>
                            <div className='th-left'>
                            </div>
                            <div className='th-right'>
                                {/* <Link to="/" className='btn common-btn t-btn1'>+ New Order</Link> */}
                                <button className='btn common-btn t-btn2'><BsPrinter className='me-1' />Print</button>
                            </div>
                        </div>
                        <div className='table-form-row'>
                            <form className='row'>
                                
                                <div className='form-group col-xxl-3 col-xl-3 col-sm-4'>
                                    <label>Search Party</label>
                                    <Select
                                        defaultValue={selectedOption}
                                        onChange={setSelectedOption}
                                        options={options}
                                    />
                                </div>
                                <div className='form-group col-xxl-2 col-xl-3 col-sm-4'>
                                    <label>Date From</label>
                                    <input type='date' placeholder='' className='form-control' />
                                </div>
                                <div className='form-group col-xxl-2 col-xl-3 col-sm-4'>
                                    <label>Date To</label>
                                    <input type='date' className='form-control' />
                                </div>
                              
                                <div className='form-group col-md-auto col-sm-4 form-btn d-flex align-items-end'>
                                    <button type='button' className='btn form-control submit-btn common-btn'><IoMdSearch /></button>
                                </div>


                            </form>
                        </div>

                        <div className='table-main-row'>
                            <div className='table-top-heading'>
                                <div className=''><p>Average Rate (INR):</p></div>
                            </div>
                            <div className='table-responsive'>
                                <table className='table table-striped table-bordered'>
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Date</th>
                                            <th>Party</th>
                                            <th>Token No</th>
                                            <th>Vehicle No</th>
                                            <th>Ref. SO.</th>
                                            <th>Po</th>
                                            <th>Gross WT (MT)</th>
                                            <th>Tare WT (MT)	</th>
                                            <th>Material WT (MT)	</th>
                                            <th>Invoice Amt	</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>

                                        </tr>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>

                                        </tr>
                                        
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </>
    )
}

export default RawStockBill