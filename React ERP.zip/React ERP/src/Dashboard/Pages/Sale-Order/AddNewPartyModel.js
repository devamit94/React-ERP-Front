import React, { useState } from 'react'
import 'react-responsive-modal/styles.css';
import { Modal } from 'react-responsive-modal';


const AddNewPartyModel = ({ open, onClose }) => {

    return (
        <>

            <section className='add-new-party'>
                <div className='container'>
                    <Modal
                        open={open}
                        onClose={onClose}
                        center
                        classNames={{
                            modal: 'custom-modal1'
                        }}
                    >
                        <div className='custom-modal1-body'>
                            <div className='model-header'>
                                <h4>Add New Party</h4>
                            </div>
                            <form>
                                <div className='container-1'>
                                    <div className='row'>
                                        <div className='form-group col-xxl-3 col-xl-3 col-sm-6'>
                                            <label>Party Name</label>
                                            <input type='text' placeholder='Party Name' className='form-control' />
                                        </div>
                                        <div className='form-group col-xxl-3 col-xl-3 col-sm-6'>
                                            <label>Short Code</label>
                                            <input type='text' placeholder='Short Code' className='form-control' />
                                        </div>
                                        <div className='form-group col-xxl-3 col-xl-3 col-sm-6'>
                                            <label>GST No.</label>
                                            <div class="input-group mb-3">
                                                <input type="text" class="form-control" placeholder="GST" aria-label="Recipient's username" aria-describedby="button-addon2" />
                                                <button class="btn btn-outline-secondary btn-primary text-white" type="button" id="button-addon2">Verify</button>
                                            </div>
                                        </div>
                                        <div className='form-group col-xxl-3 col-xl-3 col-sm-6'>
                                            <label>Contact No.</label>
                                            <input type='text' placeholder='Contact No' className='form-control' />
                                        </div>
                                        <div className='form-group col-xxl-3 col-xl-3 col-sm-6 mt-3'>
                                            <label>E-mail </label>
                                            <input type='text' placeholder='E-mail' className='form-control' />
                                        </div>
                                        <div className='form-group col-xxl-3 col-xl-3 col-sm-6 mt-3'>
                                            <label>Contact Person  </label>
                                            <input type='text' placeholder='Contact Person' className='form-control' />
                                        </div>
                                        <div className='form-group col-xxl-3 col-xl-3 col-sm-6 mt-3'>
                                            <label>Designation</label>
                                            <input type='text' placeholder='Designation' className='form-control' />
                                        </div>
                                        <div className='form-group col-xxl-3 col-xl-3 col-sm-6 mt-3'>
                                            <label>Address</label>
                                            <input type='text' placeholder='Address' className='form-control' />
                                        </div>
                                        <div className='form-group col-xxl-3 col-xl-3 col-sm-6 mt-3'>
                                            <label>State</label>
                                            <input type='text' placeholder='State' className='form-control' />
                                        </div>
                                        <div className='form-group col-xxl-3 col-xl-3 col-sm-6 mt-3'>
                                            <label>City</label>
                                            <input type='text' placeholder='City' className='form-control' />
                                        </div>
                                        <div className='form-group col-xxl-3 col-xl-3 col-sm-6 mt-3'>
                                            <label>Pincode</label>
                                            <input type='text' placeholder='Pincode' className='form-control' />
                                        </div>
                                        <div className='form-group col-xxl-3 col-xl-3 col-sm-6 mt-3'>
                                            <label>Party Type</label>
                                            <div className='d-flex gap-3 align-items-center'>
                                                <div className='radio-column d-flex gap-1 align-items-center'>
                                                    <input type='Checkbox' />
                                                    <label className='m-0'>Buyer</label>
                                                </div>
                                                <div className='radio-column d-flex gap-1 align-items-center'>
                                                    <input type='Checkbox' />
                                                    <label className='m-0'>Supplier</label>
                                                </div>
                                                <div className='radio-column d-flex gap-1 align-items-center'>
                                                    <input type='Checkbox' />
                                                    <label className='m-0'>Financer</label>
                                                </div>


                                            </div>
                                        </div>

                                        <div className='row align-items-end'>

                                            <div className='form-group col-md-auto col-sm-4 form-btn mt-4'>
                                                <button type='button' className='btn form-control submit-btn1 common-btn'>Add To Parties</button>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </Modal>
                </div>
            </section>
        </>
    )
}

export default AddNewPartyModel