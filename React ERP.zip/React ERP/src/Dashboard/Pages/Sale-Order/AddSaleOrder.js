import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { BsPrinter } from "react-icons/bs";
import Select from 'react-select';
import { IoMdSearch } from 'react-icons/io';


import AddNewPartyModel from './AddNewPartyModel';
import AddNewBrokerModel from './AddNewBrokerModel';
import { MdDelete } from 'react-icons/md';
import { FaLongArrowAltDown } from 'react-icons/fa';

const options = [
    { value: 'chocolate', label: 'Chocolate' },
    { value: 'strawberry', label: 'Strawberry' },
    { value: 'vanilla', label: 'Vanilla' },
];



const AddSaleOrder = () => {
    //model
    const [openModal, setOpenModal] = useState(false);
    const handleOpenModal = () => setOpenModal(true);
    const handleCloseModal = () => setOpenModal(false);
    //model-1
    const [openModal1, setOpenModal1] = useState(false);
    const handleOpenModal1 = () => setOpenModal1(true);
    const handleCloseModal1 = () => setOpenModal1(false);
    //model-end
    const [selectedOption, setSelectedOption] = useState(null);





    //hide show div 
    const [showCreditDays, setShowCreditDays] = useState(false);
    const [showLoadingDays, setShowLoadingDays] = useState(false);
    const CreditBtn = (event) => {
        const value = event.target.value;
        setShowCreditDays(value === 'Credit');
    };
    const Loading = (event) => {
        const value = event.target.value;
        setShowLoadingDays(value === 'Excluded');
    };
    //hide show div-end

    //add new-row
    const [rows, setRows] = useState([{}]);
    const addRow = () => {
        setRows([...rows, {}]);
    };
    const deleteRow = (index) => {
        // console.log('index',index);


        setRows(rows.filter((_, rowIndex) => rowIndex !== index));
    };

    return (
        <>
            <section id="main" className={`main`}>
                <div className='container-fluid'>
                    <div className='page-main-header'>
                        <div className='page-title'>
                            <h4>Add Sale Oredr</h4>
                        </div>

                        <div className='page-right'>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><Link to="/">Dashboard</Link></li>
                                    <li class="breadcrumb-item active" aria-current="page">Sale Oredr</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div className='main-table mt-30'>
                        <div className='table-header'>
                            <div className='th-left'>
                            </div>
                            <div className='th-right'>
                                <Link to="/sale-Order" className='btn common-btn t-btn1'>View Order</Link>
                                {/* <button className='btn common-btn t-btn2'><BsPrinter className='me-1' />Print</button> */}
                            </div>
                        </div>
                        <form className=''>
                            <div className='table-form-row'>


                                <div className='row'>
                                    <div className='col-12 col-md-12'>
                                        <div className='form-inner-title'>
                                            <h6>Buyer Details</h6>
                                        </div>
                                    </div>
                                    <div className='form-group col-xxl-3 col-xl-3 col-sm-4'>
                                        <label className='d-flex align-items-center  gap-3'>
                                            <span>Buyer Name</span>
                                            <button className='add-btn btn' type="button" onClick={handleOpenModal}>+ Add New</button>
                                        </label>
                                        <Select
                                            defaultValue={selectedOption}
                                            onChange={setSelectedOption}
                                            options={options}
                                        />

                                    </div>
                                    <div className='form-group col-xxl-3 col-xl-3 col-sm-4'>
                                        <label>GST No.</label>
                                        <input type='text' placeholder='Order No' className='form-control' />


                                    </div>
                                    <div className='form-group col-xxl-3 col-xl-3 col-sm-4'>
                                        <label>Contact Person</label>
                                        <input type='text' placeholder='' className='form-control' />
                                    </div>
                                    <div className='form-group col-xxl-3 col-xl-3 col-sm-4'>
                                        <label>Contact No.</label>
                                        <input type='text' className='form-control' />
                                    </div>

                                </div>

                                <div className='row'>
                                    <div className='col-12 col-md-12'>
                                        <div className='form-inner-title mt-3'>
                                            <h6>Broker (Optional)</h6>
                                        </div>
                                    </div>
                                    <div className='form-group col-xxl-3 col-xl-3 col-sm-6 col-12'>
                                        <label className='d-flex align-items-center  gap-3'>
                                            <span>Buyer Name</span>
                                            <button className='add-btn btn' type="button" onClick={handleOpenModal1}>+ Add New</button>
                                        </label>
                                        <Select
                                            defaultValue={selectedOption}
                                            onChange={setSelectedOption}
                                            options={options}
                                        />

                                    </div>
                                    <div className='form-group col-xxl-3 col-xl-3 col-sm-4'>
                                        <label>Contact No.</label>
                                        <input type='text' placeholder='Order No' className='form-control' />


                                    </div>
                                    <div className='form-group col-xxl-3 col-xl-3 col-sm-4'>
                                        <label>Brokerage/MT</label>
                                        <input type='number' placeholder='' className='form-control' />
                                    </div>
                                    <div className='form-group col-xxl-3 col-xl-3 col-sm-4'>
                                        <label>Customer PO No</label>
                                        <input type='text' className='form-control' />
                                    </div>

                                </div>
                                <div className='row'>
                                    <div className='col-12 col-md-12'>
                                        <div className='form-inner-title mt-3'>
                                            <h6>Order Pricing</h6>
                                        </div>
                                    </div>

                                    <div className='form-group col-xxl-3 col-xl-3 col-sm-4'>
                                        <label>Basic Rate </label>
                                        <input type='Number' placeholder='' className='form-control' />


                                    </div>
                                    <div className='form-group col-xxl-3 col-xl-3 col-sm-4'>
                                        <label>Rolling Rate </label>
                                        <input type='Number' placeholder='' className='form-control' />
                                    </div>
                                    <div className='form-group col-xxl-3 col-xl-3 col-sm-4'>
                                        <label>Rate</label>
                                        <input type='text' className='form-control' value="0" />
                                    </div>

                                </div>
                                <div className='row'>
                                    <div className='col-12 col-md-12'>
                                        <div className='form-inner-title mt-3'>
                                            <h6>Order Qty</h6>
                                        </div>
                                    </div>

                                    <div className='form-group col-xxl-3 col-xl-3 col-sm-4'>
                                        <label>Total Qty (MT).</label>
                                        <input type='Number' placeholder='Order No' className='form-control' />


                                    </div>
                                    <div className='form-group col-xxl-3 col-xl-3 col-sm-4'>
                                        <label>Order Date</label>
                                        <input type='date' placeholder='' className='form-control' />
                                    </div>
                                    <div className='form-group col-xxl-3 col-xl-3 col-sm-4'>
                                        <label>Raw Material</label>
                                        <Select
                                            defaultValue={selectedOption}
                                            onChange={setSelectedOption}
                                            options={options}
                                        />
                                    </div>
                                    <div className='form-group col-xxl-3 col-xl-3 col-sm-4'>
                                        <label>Order Important</label>
                                        <Select
                                            defaultValue={selectedOption}
                                            onChange={setSelectedOption}
                                            options={options}
                                        />
                                    </div>
                                </div>

                                <div className='row'>
                                    <div className='col-12 col-md-12'>
                                        <div className='form-inner-title mt-3'>
                                            <h6>Terms & Conditions</h6>
                                        </div>
                                    </div>
                                    <div className='form-group col-xxl-2 col-xl-2 col-sm-4'>
                                        <label>Delivery Terms</label>
                                        <div className='d-flex gap-4'>
                                            <div className='radio-column d-flex gap-2 align-items-center'>
                                                <input type='radio' value="EX" id="ex" name="delivery_terms" />
                                                <label for="ex" >EX</label>
                                            </div>
                                            <div className='radio-column d-flex gap-2'>
                                                <input type='radio' value="FOR" id="for" name="delivery_terms" />
                                                <label for="for">FOR</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div className='form-group col-xxl-3 col-xl-3 col-sm-4'>
                                        <label>Payment Terms</label>
                                        <div className='d-flex gap-4'>
                                            <div className='radio-column d-flex gap-2 align-items-center'>
                                                <input
                                                    type='radio'
                                                    value="Advance"
                                                    id="advance"
                                                    name="payment_terms"
                                                    onClick={CreditBtn}
                                                />
                                                <label htmlFor="advance">Advance</label>
                                            </div>
                                            <div className='radio-column d-flex gap-2'>
                                                <input
                                                    type='radio'
                                                    value="Credit"
                                                    id="credit"
                                                    name="payment_terms"
                                                    onClick={CreditBtn}
                                                />
                                                <label htmlFor="credit">Credit</label>
                                            </div>
                                            <div className='radio-column d-flex gap-2'>
                                                <input
                                                    type='radio'
                                                    value="None"
                                                    id="none"
                                                    name="payment_terms"
                                                    onClick={CreditBtn}
                                                />
                                                <label htmlFor="none">None</label>
                                            </div>
                                        </div>
                                    </div>

                                    {showCreditDays && (
                                        <div id="hideShow" className='form-group col-xxl-2 col-xl-2 col-sm-6'>
                                            <label>Credit Days</label>
                                            <input
                                                type='number'
                                                placeholder='Credit Days'
                                                className='form-control'
                                            />
                                        </div>
                                    )}

                                    <div className='form-group col-xxl-3 col-xl-3 col-sm-4'>
                                        <label>Loading Charge (INR)</label>
                                        <div className='d-flex gap-4'>
                                            <div className='radio-column d-flex gap-2 align-items-center'>
                                                <input type='radio' value="Excluded" id="excluded" name="freight" onClick={Loading} />
                                                <label for="excluded" >Excluded</label>
                                            </div>

                                            <div className='radio-column d-flex gap-2'>
                                                <input type='radio' value="Included" id="included" name="freight" onClick={Loading} />
                                                <label for="included">Included</label>
                                            </div>
                                        </div>
                                    </div>
                                    {showLoadingDays && (
                                        <div id="hideShow" className='form-group col-xxl-2 col-xl-2 col-sm-6'>
                                            <label>Loading Rate</label>
                                            <input
                                                type='number'
                                                placeholder='Credit Days'
                                                className='form-control'
                                            />
                                        </div>
                                    )}
                                </div>
                                <div className='row'>
                                    <div className='col-12 col-md-12 '>
                                        <div className='form-inner-title mt-3'>
                                            <h6>Order Items</h6>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div className='table-main-row'>
                                <div className='table-responsive table-responsive-1'>
                                    <table className='table table-striped table-bordered'>
                                        <thead>
                                            <tr>
                                                <th>Product<span className='text-red'> *</span></th>
                                                <th>Grade</th>
                                                <th>Size</th>
                                                <th>Length (FT.) & Type</th>
                                                <th>Edge Type</th>
                                                <th>Weight Kg/Feet</th>
                                                <th>Weight Kg /Pcs</th>
                                                <th>Pcs</th>
                                                <th>Qty (MT)*</th>
                                                <th>Rate/MT</th>
                                                <th>Extra/MT</th>
                                                <th>Net Rate</th>
                                                <th>Total</th>
                                                <th><button type='button' className='add-tr-btn btn' onClick={addRow}>+</button></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {/* <tr>
                                                <td>
                                                    <div className='form-group'>
                                                        <select className='form-control'>
                                                            <option>Select One</option>
                                                            <option>Select One</option>
                                                            <option>Select One</option>
                                                        </select>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div className='form-group'>
                                                        <select className='form-control'>
                                                            <option>Select One</option>
                                                            <option>Select One</option>
                                                            <option>Select One</option>
                                                        </select>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div className='form-group'>
                                                        <select className='form-control'>
                                                            <option>Select One</option>
                                                            <option>Select One</option>
                                                            <option>Select One</option>
                                                        </select>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div className='form-group'>
                                                        <div class="input-group">
                                                            <input type="number" class="form-control" aria-label="Text input with segmented dropdown button" />
                                                            <div class="input-group-append">
                                                                <select className='form-control'>
                                                                    <option>Select One</option>
                                                                    <option>Select One</option>
                                                                    <option>Select One</option>
                                                                </select>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div className='form-group'>
                                                        <select className='form-control'>
                                                            <option>Select One</option>
                                                            <option>Select One</option>
                                                            <option>Select One</option>
                                                        </select>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div className='form-group'>
                                                        <input type="number" className='form-control' placeholder='weight' />
                                                    </div>
                                                </td>
                                                <td>
                                                    <div className='form-group'>
                                                        <input type="number" className='form-control' placeholder='weight' />
                                                    </div>
                                                </td>
                                                <td>
                                                    <div className='form-group'>
                                                        <input type="number" className='form-control' placeholder='weight' />
                                                    </div>
                                                </td>
                                                <td>
                                                    <div className='form-group'>
                                                        <input type="number" className='form-control' placeholder='weight' />
                                                    </div>
                                                </td>
                                                <td>
                                                    <div className='form-group'>
                                                        <input type="number" className='form-control' placeholder='weight' />
                                                    </div>
                                                </td>
                                                <td>
                                                    <div className='form-group'>
                                                        <input type="number" className='form-control' placeholder='weight' />
                                                    </div>
                                                </td>
                                                <td>
                                                    <div className='form-group'>
                                                        <input type="number" className='form-control' placeholder='0' value={0} />
                                                    </div>
                                                </td>
                                                <td>
                                                    <div className='form-group'>
                                                        <input type="number" className='form-control' placeholder='0' value={0} />
                                                    </div>
                                                </td>


                                            </tr> */}
                                            {rows.map((_, index) => (
                                                <tr key={index}>
                                                    <td>
                                                        <div className='form-group'>
                                                            <select className='form-control'>
                                                                <option>Select One</option>
                                                                <option>Select One</option>
                                                                <option>Select One</option>
                                                            </select>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div className='form-group'>
                                                            <select className='form-control'>
                                                                <option>Select One</option>
                                                                <option>Select One</option>
                                                                <option>Select One</option>
                                                            </select>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div className='form-group'>
                                                            <select className='form-control'>
                                                                <option>Select One</option>
                                                                <option>Select One</option>
                                                                <option>Select One</option>
                                                            </select>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div className='form-group'>
                                                            <div className="input-group">
                                                                <input type="number" className="form-control" aria-label="Text input with segmented dropdown button" />
                                                                <div className="input-group-append">
                                                                    <select className='form-control'>
                                                                        <option>Select One</option>
                                                                        <option>Select One</option>
                                                                        <option>Select One</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div className='form-group'>
                                                            <select className='form-control'>
                                                                <option>Select One</option>
                                                                <option>Select One</option>
                                                                <option>Select One</option>
                                                            </select>
                                                        </div>
                                                    </td>
                                                    <td><input type="number" className='form-control' placeholder='weight' /></td>
                                                    <td><input type="number" className='form-control' placeholder='weight' /></td>
                                                    <td><input type="number" className='form-control' placeholder='weight' /></td>
                                                    <td><input type="number" className='form-control' placeholder='weight' /></td>
                                                    <td><input type="number" className='form-control' placeholder='weight' /></td>
                                                    <td><input type="number" className='form-control' placeholder='weight' /></td>
                                                    <td><input type="number" className='form-control' placeholder='0' value={0} /></td>
                                                    <td><input type="number" className='form-control' placeholder='0' value={0} /></td>
                                                    <td className='td-action td-action-py'>
                                                        <a className='delete' onClick={() => deleteRow(index)}>
                                                            <MdDelete className='d-icon' />
                                                        </a></td>
                                                </tr>
                                            ))}
                                            <tr>
                                                <td colSpan="8" className="text-end fw-bold">Total</td>
                                                <td>0.000</td>
                                                <td>0.000</td>
                                                <td>0.000</td>
                                            </tr>




                                        </tbody>
                                    </table>
                                </div>
                            </div>


                            <div className='row main-accordian-row px-15'>
                                <div class="accordion accordion-flush" id="accordionFlushExample">
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="flush-headingAdd">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseAdd" aria-expanded="false" aria-controls="flush-collapseAdd">
                                                <div className='acc-css w-100 d-flex align-items-center justify-content-between'>
                                                    <span>Add Optionals</span>
                                                    <span className='dropicon'><FaLongArrowAltDown className='icon' /></span>
                                                </div>
                                            </button>
                                        </h2>
                                        <div id="flush-collapseAdd" class="accordion-collapse collapse" aria-labelledby="flush-headingAdd" data-bs-parent="#accordionFlushExample">
                                            <div class="accordion-body accordion-body-ab">
                                                <div className='form-inner-title mt-3'>
                                                    <h6>Raw Material Route</h6>
                                                </div>
                                                <div className='form-group d-flex align-items-center gap-3'>
                                                    <div className='fg-checkbox d-flex align-items-center gap-1'>
                                                        <input id="" type="checkbox" name="" value="" />
                                                        <label for="" className='mb-0'>LRF</label>
                                                    </div>
                                                    <div className='fg-checkbox d-flex align-items-center gap-1'>
                                                        <input id="" type="checkbox" name="" value="" />
                                                        <label for="" className='mb-0'>VD</label>
                                                    </div>
                                                    <div className='fg-checkbox d-flex align-items-center gap-1'>
                                                        <input id="" type="checkbox" name="" value="" />
                                                        <label for="" className='mb-0'>CC</label>
                                                    </div>
                                                    <div className='fg-checkbox d-flex align-items-center gap-1'>
                                                        <input id="" type="checkbox" name="" value="" />
                                                        <label for="" className='mb-0'>HTL with Grinding</label>
                                                    </div>
                                                    <div className='fg-checkbox d-flex align-items-center gap-1'>
                                                        <input id="" type="checkbox" name="" value="" />
                                                        <label for="" className='mb-0'>XRF</label>
                                                    </div>
                                                    <div className='fg-checkbox d-flex align-items-center gap-1'>
                                                        <input id="" type="checkbox" name="" value="" />
                                                        <label for="" className='mb-0'>UT</label>
                                                    </div>
                                                    <div className='fg-checkbox d-flex align-items-center gap-1'>
                                                        <input id="" type="checkbox" name="" value="" />
                                                        <label for="" className='mb-0'>MPI</label>
                                                    </div>
                                                </div>

                                                <div className='form-inner-title mt-3'>
                                                    <h6>Physical Inspection Checks</h6>
                                                </div>

                                                <div className='form-group d-flex align-items-center gap-3'>
                                                    <div className='fg-checkbox d-flex align-items-center gap-1'>
                                                        <input id="" type="checkbox" name="" value="" />
                                                        <label for="" className='mb-0'>Visual Inspection</label>
                                                    </div>
                                                    <div className='fg-checkbox d-flex align-items-center gap-1'>
                                                        <input id="" type="checkbox" name="" value="" />
                                                        <label for="" className='mb-0'>Size Check</label>
                                                    </div>
                                                    <div className='fg-checkbox d-flex align-items-center gap-1'>
                                                        <input id="" type="checkbox" name="" value="" />
                                                        <label for="" className='mb-0'>UT</label>
                                                    </div>
                                                    <div className='fg-checkbox d-flex align-items-center gap-1'>
                                                        <input id="" type="checkbox" name="" value="" />
                                                        <label for="" className='mb-0'>XRF</label>
                                                    </div>

                                                </div>

                                                <div className='form-group'>
                                                    <label for="" >Order Remark (Visible To Customer & Prints)</label>
                                                    <textarea className='form-control'></textarea>
                                                </div>

                                                <div className='form-inner-title mt-3'>
                                                    <h6>Remarks For Internal Use</h6>
                                                </div>

                                                <div className='form-group'>
                                                    <label for="" >Production Planning</label>
                                                    <textarea className='form-control'></textarea>
                                                </div>

                                                <div className='form-group'>
                                                    <label for="" >Rolling/Production Remark</label>
                                                    <textarea className='form-control'></textarea>
                                                </div>

                                                <div className='form-group'>
                                                    <label for="" >Inspection Remarks</label>
                                                    <textarea className='form-control'></textarea>
                                                </div>

                                                <div className='form-group'>
                                                    <label for="" >Dispatch Remark</label>
                                                    <textarea className='form-control'></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div className='col-12 '>
                                <div className='form-group-1 mt-3'>
                                    <button type='button' className='btn form-control submit-btn1 common-btn'>Submit</button>
                                </div>
                            </div>
                            <div className='row main-accordian-row '></div>


                        </form>
                    </div>
                </div>
            </section>

            {/* Modal */}
            <AddNewPartyModel open={openModal} onClose={handleCloseModal} />
            <AddNewBrokerModel open={openModal1} onClose={handleCloseModal1} />
        </>
    )
}

export default AddSaleOrder
