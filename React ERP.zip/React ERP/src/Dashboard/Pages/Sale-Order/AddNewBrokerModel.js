import React, { useState } from 'react'
import 'react-responsive-modal/styles.css';
import { Modal } from 'react-responsive-modal';

const AddNewBrokerModel = ({ open, onClose }) => {
    return (
        <>
       
            <section className='add-new-party'>
                <div className='container'>
                    <Modal
                        open={open}
                        onClose={onClose}
                        center
                        classNames={{
                            modal: 'custom-modal1'
                        }}
                    >
                        <div className='custom-modal1-body'>
                            <div className='model-header'>
                                <h4>Add New Buyer</h4>
                            </div>
                            <form>
                                <div className='container-1'>
                                    <div className='row'>
                                        <div className='form-group col-xxl-3 col-xl-3 col-sm-6'>
                                            <label>Broker Name</label>
                                            <input type='text' placeholder='Party Name' className='form-control' />
                                        </div>
                                        <div className='form-group col-xxl-3 col-xl-3 col-sm-6'>
                                            <label>Contact No</label>
                                            <input type='text' placeholder='Short Code' className='form-control' />
                                        </div>

                                        <div className='form-group col-xxl-3 col-xl-3 col-sm-6 mt-3'>
                                            <label>Address</label>
                                            <input type='text' placeholder='Address' className='form-control' />
                                        </div>
                                        <div className='form-group col-xxl-3 col-xl-3 col-sm-6 mt-3'>
                                            <label>State</label>
                                            <input type='text' placeholder='State' className='form-control' />
                                        </div>
                                        <div className='form-group col-xxl-3 col-xl-3 col-sm-6 mt-3'>
                                            <label>City</label>
                                            <input type='text' placeholder='City' className='form-control' />
                                        </div>
                                        <div className='form-group col-xxl-3 col-xl-3 col-sm-6 mt-3'>
                                            <label>Pincode</label>
                                            <input type='text' placeholder='Pincode' className='form-control' />
                                        </div>

                                        <div className='form-group col-md-auto col-sm-4 form-btn mt-4'>
                                            <button type='button' className='btn form-control submit-btn1 common-btn mt-3'>Add To Buyer</button>
                                        </div>

                                    </div>
                                </div>
                            </form>

                        </div>
                    </Modal>
                </div>
            </section>


        </>
    )
}

export default AddNewBrokerModel