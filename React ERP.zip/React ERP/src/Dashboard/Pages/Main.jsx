import React from 'react'
import { Link } from 'react-router-dom'
import { BsBookmarkCheckFill, BsBoxes, BsReceiptCutoff } from "react-icons/bs";
import { FaBasketShopping } from "react-icons/fa6";
import { MdOutlinePendingActions } from "react-icons/md";
import { IoBag, IoBagAdd } from "react-icons/io5";
import { FaRupeeSign, FaTruckMoving } from 'react-icons/fa';
import reportIcon from '../../Assets/img/report2.gif'
import ApexChartMain from '../Components/ApexChartMain';
import PriceMainChart from '../Components/PriceMainChart';
import OrderMainChart from '../Components/OrderMainChart';
const Main = ({ TOS }) => {
    return (
        <>
            
            <section id="main" className={`main`}>
                <div className='container-fluid'>
                    <div className='page-title'>
                        <h4>Dashboard</h4>
                    </div>
                    <div className='row '>
                        <div className="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-3">
                            <div className="card main-card">
                                <Link to="">
                                    <div className='card-content'>
                                        <div className='card-title'>
                                            <h4>0 MT</h4>
                                            <p>Raw materials</p>
                                        </div>
                                        <div className='card-icon ci-1'>
                                            <span><BsBookmarkCheckFill className='icon icon1' /></span>
                                        </div>
                                    </div>
                                </Link>
                            </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-3">
                            <div className="card main-card">
                                <Link to="">
                                    <div className='card-content'>
                                        <div className='card-title'>
                                            <h4>0 MT</h4>
                                            <p>Finished Products</p>
                                        </div>
                                        <div className='card-icon ci-2'>
                                            <span><FaBasketShopping className='icon icon1' /></span>
                                        </div>
                                    </div>
                                </Link>
                            </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-3">
                            <div className="card main-card">
                                <Link to="">
                                    <div className='card-content'>
                                        <div className='card-title'>
                                            <h4>0 MT</h4>
                                            <p>Pending Sale Order</p>
                                        </div>
                                        <div className='card-icon ci-3'>
                                            <span><MdOutlinePendingActions className='icon icon1' /></span>
                                        </div>
                                    </div>
                                </Link>
                            </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-3">
                            <div className="card main-card">
                                <Link to="">
                                    <div className='card-content'>
                                        <div className='card-title'>
                                            <h4>0 MT</h4>
                                            <p>Pending Purchase Orders</p>
                                        </div>
                                        <div className='card-icon ci-4'>
                                            <span><IoBagAdd className='icon icon1' /></span>
                                        </div>
                                    </div>
                                </Link>
                            </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-3">
                            <div className="card main-card">
                                <Link to="">
                                    <div className='card-content'>
                                        <div className='card-title'>
                                            <h4>0 </h4>
                                            <p>Pending Purchase Orders</p>
                                        </div>
                                        <div className='card-icon ci-5'>
                                            <span><IoBag className='icon icon1' /></span>
                                        </div>
                                    </div>
                                </Link>
                            </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-3">
                            <div className="card main-card">
                                <Link to="">
                                    <div className='card-content'>
                                        <div className='card-title'>
                                            <h4>0 ₹</h4>
                                            <p>Sale Average Price</p>
                                        </div>
                                        <div className='card-icon ci-1'>
                                            <span><FaRupeeSign className='icon icon1' /></span>
                                        </div>
                                    </div>
                                </Link>
                            </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-3">
                            <div className="card main-card">
                                <Link to="">
                                    <div className='card-content'>
                                        <div className='card-title'>
                                            <h4>0 ₹</h4>
                                            <p>MS Purchase Average Price</p>
                                        </div>
                                        <div className='card-icon ci-2'>
                                            <span><FaRupeeSign className='icon icon1' /></span>
                                        </div>
                                    </div>
                                </Link>
                            </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-3">
                            <div className="card main-card">
                                <Link to="">
                                    <div className='card-content'>
                                        <div className='card-title'>
                                            <h4>0 ₹</h4>
                                            <p>MS Sale Average Price</p>
                                        </div>
                                        <div className='card-icon ci-3'>
                                            <span><FaRupeeSign className='icon icon1' /></span>
                                        </div>
                                    </div>
                                </Link>
                            </div>
                        </div>
                    </div>
                    <div className="row mt-50">
                        <div className='col-12'>
                            <div className='main-chart'>
                                <ApexChartMain />
                            </div>
                        </div>
                    </div>


                    <div className='row mt-50'>
                        <div className="col-12">
                            <div className="page-header">
                                <div className="column-left d-flex align-items-center">
                                    <img src={reportIcon} alt="" />
                                    <h6>Daily Reports</h6>
                                </div>
                                <div className="column-right"></div>
                            </div>
                        </div>

                        <div className="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-4">
                            <div className="card main-card1">
                                <Link to="">
                                    <div className='card-content1'>
                                        <div className='card-icon ci1'>
                                            <span><BsBoxes className='icon icon1' /></span>
                                        </div>
                                        <div className='card-title'>
                                            <h4>0 MT</h4>
                                            <p>Raw Material</p>
                                        </div>

                                    </div>
                                </Link>
                            </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-4">
                            <div className="card main-card1">
                                <Link to="">
                                    <div className='card-content1'>
                                        <div className='card-icon ci2'>
                                            <span><BsReceiptCutoff className='icon icon1' /></span>
                                        </div>
                                        <div className='card-title'>
                                            <h4>0 MT</h4>
                                            <p>Production</p>
                                        </div>

                                    </div>
                                </Link>
                            </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-4">
                            <div className="card main-card1">
                                <Link to="">
                                    <div className='card-content1'>
                                        <div className='card-icon ci3'>
                                            <span><IoBagAdd className='icon icon1' /></span>
                                        </div>
                                        <div className='card-title'>
                                            <h4>0 MT</h4>
                                            <p>Sale</p>
                                        </div>

                                    </div>
                                </Link>
                            </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-4">
                            <div className="card main-card1">
                                <Link to="">
                                    <div className='card-content1'>
                                        <div className='card-icon ci4'>
                                            <span><IoBagAdd className='icon icon1' /></span>
                                        </div>
                                        <div className='card-title'>
                                            <h4>0 MT</h4>
                                            <p>Purchase</p>
                                        </div>

                                    </div>
                                </Link>
                            </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-4">
                            <div className="card main-card1">
                                <Link to="">
                                    <div className='card-content1'>
                                        <div className='card-icon ci5'>
                                            <span><FaTruckMoving className='icon icon1' /></span>
                                        </div>
                                        <div className='card-title'>
                                            <h4>0 MT</h4>
                                            <p>Dispatch</p>
                                        </div>

                                    </div>
                                </Link>
                            </div>
                        </div>
                    </div>


                    <div className='row mt-50'>
                        <div className="col-12 col-sm-12 col-md-6">
                            <div className='main-chart'>
                                <div className="chart-header">
                                    {/* <h6>Price Report</h6> */}
                                    <PriceMainChart />
                                </div>

                            </div>
                        </div>
                        <div className="col-12 col-sm-12 col-md-6">
                            <div className='main-chart'>
                                <div className="chart-header">
                                    {/* <h6>Order Report</h6> */}
                                    <OrderMainChart />
                                </div>
                            </div>
                        </div>

                    </div>

                    <div className='row mt-50'></div>

                </div>
            </section>
        </>
    )
}

export default Main