import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { BsPrinter } from "react-icons/bs";
import Select from 'react-select';
import { IoMdSearch } from 'react-icons/io';

const options = [
    { value: 'chocolate', label: 'Chocolate' },
    { value: 'strawberry', label: 'Strawberry' },
    { value: 'vanilla', label: 'Vanilla' },
];

const Grades = () => {
    const [selectedOption, setSelectedOption] = useState(null);
    return (
        <>
            <section id="main" className={`main`}>
                <div className='container-fluid'>
                    <div className='page-main-header'>
                        <div className='page-title'>
                            <h4>All Grades</h4>
                        </div>

                        <div className='page-right'>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><Link to="/">Dashboard</Link></li>
                                    <li class="breadcrumb-item active" aria-current="page">All Grades</li>
                                </ol>
                            </nav>
                        </div>
                    </div>


                    <div className='main-table mt-30'>
                        <div className='table-header'>
                            <div className='th-left'>
                            </div>
                            <div className='th-right'>
                                <Link to="/add-sale-order" className='btn common-btn t-btn1'>+ New Grade</Link>
                                <button className='btn common-btn t-btn2'><BsPrinter className='me-1' />Print</button>
                            </div>
                        </div>
                        <div className='table-form-row'>
                            <form className='row'>
                                <div className='form-group col-xxl-4 col-xl-3 col-md-4 col-sm-6'>
                                    <label>Search Grade</label>
                                    <input type='text' placeholder='Search Grade' className='form-control' />
                                </div>

                                <div className='form-group col-md-auto col-sm-4 form-btn d-flex align-items-end'>
                                    <button type='button' className='btn form-control submit-btn common-btn'><IoMdSearch /></button>
                                </div>


                            </form>
                        </div>

                        <div className='table-main-row'>
                            <div className='table-top-heading'>
                                <div className=''><p>Average Rate (INR):</p></div>
                            </div>
                            <div className='table-responsive'>
                                <table className='table table-striped table-bordered'>
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Grade</th>
                                            <th>C</th>
                                            <th>Si</th>
                                            <th>Mn</th>
                                            <th>P</th>
                                            <th>S</th>
                                            <th>Cr</th>
                                            <th>Mo</th>
                                            <th>Ni</th>
                                            <th>Al</th>
                                            <th>Cu</th>
                                            <th>V</th>
                                            <th>Nb</th>
                                            <th>Ti</th>
                                            <th>Sn</th>
                                            <th>CE</th>
                                            <th>B</th>
                                            <th>W</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>080M42/UG (M)</td>
                                            <td>
                                                <span class="text-success">Min</span> 0.40<br />
                                                <span class="text-primary">Max</span> 0.45
                                            </td>
                                            <td>0.15</td>
                                            <td>
                                                <span class="text-success">Min</span> 0.70<br />
                                                <span class="text-primary">Max</span> 0.90
                                            </td>
                                            <td>0.050</td>
                                            <td>0.050</td>
                                            <td>0.30</td>
                                            <td>0.15</td>
                                            <td>0.40</td>
                                            <td></td>
                                            <td>0.35</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>0.66</td>
                                            <td></td>
                                            <td></td>
                                            <td>
                                                <button class="btn btn-success btn-sm"><i class="fas fa-save"></i></button>
                                                <button class="btn btn-primary btn-sm"><i class="fas fa-edit"></i></button>
                                                <button class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i></button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>2</td>
                                            <td>16MnCr5</td>
                                            <td>
                                                <span class="text-success">Min</span> 0.14<br />
                                                <span class="text-primary">Max</span> 0.19
                                            </td>
                                            <td>0.35</td>
                                            <td>
                                                <span class="text-success">Min</span> 1.00<br />
                                                <span class="text-primary">Max</span> 1.30
                                            </td>
                                            <td>0.020</td>
                                            <td>0.035</td>
                                            <td>1.10</td>
                                            <td>0.06</td>
                                            <td>0.25</td>
                                            <td>0.020</td>
                                            <td>0.040</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>
                                                <button class="btn btn-success btn-sm"><i class="fas fa-save"></i></button>
                                                <button class="btn btn-primary btn-sm"><i class="fas fa-edit"></i></button>
                                                <button class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i></button>
                                            </td>
                                        </tr>


                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </>
    )
}



export default Grades