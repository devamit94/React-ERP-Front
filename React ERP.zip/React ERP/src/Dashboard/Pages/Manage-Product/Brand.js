import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import Select from 'react-select';
import { IoMdSearch } from 'react-icons/io';
import { FaEdit, FaEye } from 'react-icons/fa';
import { MdDelete } from 'react-icons/md';
const options = [
    { value: 'chocolate', label: 'Chocolate' },
    { value: 'strawberry', label: 'Strawberry' },
    { value: 'vanilla', label: 'Vanilla' },
];

const Brand = () => {
    const [selectedOption, setSelectedOption] = useState(null);
    return (
        <>
            <section id="main" className={`main`}>
                <div className='container-fluid'>
                    <div className='page-main-header'>
                        <div className='page-title'>
                            <h4>Brand</h4>
                        </div>
                        <div className='page-right'>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><Link to="/">Dashboard</Link></li>
                                    <li class="breadcrumb-item active" aria-current="page">Brand</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    
                    <div className='row'>
                        <div className='col-md-8 col-sm-12 col-12'>
                            <div className='main-table mt-30'>
                                <div className='table-header'>
                                    <div className='th-left'>
                                    </div>
                                    <div className='th-right'>
                                        <Link to="/" className='btn common-btn t-btn1'>Dashboard</Link>
                                        {/* <button className='btn common-btn t-btn2'><BsPrinter className='me-1' />Print</button> */}
                                    </div>
                                </div>
                                <div className='table-form-row'>
                                    <form className='row'>
                                        <div className='form-group col-xxl-3 col-xl-3 col-sm-4'>
                                            <label>Search Brand</label>
                                            <input type='text' placeholder='' className='form-control' />
                                        </div>





                                        <div className='form-group col-md-auto col-sm-4 form-btn d-flex align-items-end'>
                                            <button type='button' className='btn form-control submit-btn1 common-btn'>Apply Filter</button>
                                        </div>


                                    </form>
                                </div>

                                <div className='table-main-row'>

                                    <div className='table-responsive'>
                                        <table className='table table-striped table-bordered'>
                                            <thead>
                                                <tr>

                                                    <th>#</th>
                                                    <th>Brand Name</th>
                                                    <th>Action</th>


                                                </tr>
                                            </thead>
                                            <tbody>

                                                <tr>
                                                    <td></td>
                                                    <td></td>
                                                    <td className='td-action'>
                                                        {/* <Link to="/" className='view'><FaEye className='d-icon' /></Link> */}
                                                        <Link to="/" className='edit'><FaEdit className='d-icon' /></Link>
                                                        {/* <a className='delete'><MdDelete className='d-icon' /></a> */}
                                                    </td>




                                                </tr>


                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className='col-md-4 col-sm-12 col-12 '>
                            <div className='add-product-column mt-30'>
                                <div className='form-inner-title'>
                                    <h6>Add New Brand</h6>
                                </div>
                                <form className='product-form'>
                                    <div className='form-group'>
                                        <label>Brand Name <span className='text-red'>*</span></label>
                                        <input type='text' placeholder='' className='form-control' />
                                    </div>


                                    <div className='form-group mt-3'>
                                        <button type='button' className='btn form-control submit-btn1 common-btn'>Add To Product</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </>
    )
}



export default Brand