import React from 'react'
import { Link } from 'react-router-dom'
import { FaHome, FaLayerGroup, FaShoppingBag, FaTruck, FaUsers, FaWifi } from 'react-icons/fa'

import { MdKeyboardArrowRight } from 'react-icons/md'
import { HiUsers } from "react-icons/hi";
import { IoBagAdd } from "react-icons/io5";
import logo from '../../Assets/img/logo.png'
import { LuDot } from "react-icons/lu";
import { CiDeliveryTruck, CiLogout, CiMoneyBill } from "react-icons/ci";
import { BiSolidContact } from "react-icons/bi";
import { GiUpgrade } from "react-icons/gi"

import { IoMdLogOut } from "react-icons/io";
const Sidebar = ({ TOS }) => {
    return (
        <>
            {/* <div id="sidebar" className={`sidebar-main ${TOS ? 'new_sidebar' : ''}`}> */}
            <div id="sidebar"  className={`sidebar-main `}>
                <div className='sidebar-overflow'>
                    <div className='sidebar-menu'>
                        <div class="accordion accordion-flush" id="accordionFlushExample">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="flush-headingOne1">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne1" aria-expanded="false" aria-controls="flush-collapseOne1">
                                        <Link to="/">
                                            <div className='sidebar-main-title'>
                                                <div className='sidebar-icon'><FaHome className='icon' /></div>
                                                <div className='sidebar-title'>Dashboard</div>
                                            </div>
                                        </Link>
                                    </button>
                                </h2>
                            </div>

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="flush-headingOne">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                                   
                                        <div className='sidebar-main-title'>
                                            <div className='sidebar-icon'><FaShoppingBag className='icon' /></div>
                                            <div className='sidebar-title'>Sale Orders</div>
                                        </div>
                                        <div className='sidebar-right-icon'>
                                            <MdKeyboardArrowRight className='arrow-icon' />
                                        </div>
                                        
                                    </button>
                                </h2>
                                <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body accordion-body-content">
                                        <ul>
                                            <li><Link to='/sale-Order'><LuDot className='dot-icon' /><span>Sale Order</span></Link></li>
                                            <li><Link to='/sale-order-items'><LuDot className='dot-icon' /><span>Sale Order Item</span></Link></li>
                                        </ul>

                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="flush-headingTwo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                                        <Link to="/average-sale-purchase">
                                            <div className='sidebar-main-title'>
                                                <div className='sidebar-icon'><HiUsers className='icon' /></div>
                                                <div className='sidebar-title'>Average Sale / Purchase</div>
                                            </div>
                                        </Link>

                                    </button>
                                </h2>

                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="flush-headingThree">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
                                        <div className='sidebar-main-title'>
                                            <div className='sidebar-icon'><IoBagAdd className='icon' /></div>
                                            <div className='sidebar-title'>Purchase Orders</div>
                                        </div>
                                        <div className='sidebar-right-icon'>
                                            <MdKeyboardArrowRight className='arrow-icon' />
                                        </div>
                                    </button>
                                </h2>
                                <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body accordion-body-content">
                                        <ul>
                                            <li><Link to='/purchase-orders'><LuDot className='dot-icon' /><span>Purchase Orders</span></Link></li>
                                            <li><Link to='/purchase-orders-reports'><LuDot className='dot-icon' /><span>Purchase Orders Report</span></Link></li>
                                            <li><Link to='/purchase-orders-item'><LuDot className='dot-icon' /><span>Purchase Orders items</span></Link></li>
                                            <li><Link to='/purchase-orders-item-reports'><LuDot className='dot-icon' /><span>Purchase Orders items Report</span></Link></li>
                                        </ul>

                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="flush-headingFour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFour" aria-expanded="false" aria-controls="flush-collapseFour">
                                        <div className='sidebar-main-title'>
                                            <div className='sidebar-icon'><IoBagAdd className='icon' /></div>
                                            <div className='sidebar-title'>Raw Stock</div>
                                        </div>
                                        <div className='sidebar-right-icon'>
                                            <MdKeyboardArrowRight className='arrow-icon' />
                                        </div>
                                    </button>
                                </h2>
                                <div id="flush-collapseFour" class="accordion-collapse collapse" aria-labelledby="flush-headingFour" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body accordion-body-content">
                                        <ul>
                                            <li><Link to='/raw-material'><LuDot className='dot-icon' /><span>Raw Stock</span></Link></li>
                                            <li><Link to='/raw-material-sizes'><LuDot className='dot-icon' /><span>Raw Stock Size</span></Link></li>
                                            <li><Link to='/raw-material-size-report'><LuDot className='dot-icon' /><span>Raw Material Reports</span></Link></li>
                                            <li><Link to='/raw-material-return-report'><LuDot className='dot-icon' /><span>Return Reports</span></Link></li>
                                        </ul>

                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="flush-headingFive">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFive" aria-expanded="false" aria-controls="flush-collapseFive">
                                        <div className='sidebar-main-title'>
                                            <div className='sidebar-icon'><IoBagAdd className='icon' /></div>
                                            <div className='sidebar-title'>Finished Stock</div>
                                        </div>
                                        <div className='sidebar-right-icon'>
                                            <MdKeyboardArrowRight className='arrow-icon' />
                                        </div>
                                    </button>
                                </h2>
                                <div id="flush-collapseFive" class="accordion-collapse collapse" aria-labelledby="flush-headingFive" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body accordion-body-content">
                                        <ul>
                                            <li><Link to='/finish-material'><LuDot className='dot-icon' /><span>Finished Material Bundles</span></Link></li>
                                            <li><Link to='/finished-material-reports'><LuDot className='dot-icon' /><span>Finished Material Reports</span></Link></li>
                                            <li><Link to='/finish-material-sizes'><LuDot className='dot-icon' /><span>Finished Material Size</span></Link></li>
                                            <li><Link to='/finish-material-grade'><LuDot className='dot-icon' /><span>Finished Material Grade</span></Link></li>
                                        </ul>

                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="flush-headingsix">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapsesix" aria-expanded="false" aria-controls="flush-collapsesix">
                                        <Link to="/rawstock-bill">
                                            <div className='sidebar-main-title'>
                                                <div className='sidebar-icon'><CiMoneyBill className='icon' /></div>
                                                <div className='sidebar-title'>Raw Stock Bill</div>
                                            </div>
                                        </Link>

                                    </button>
                                </h2>

                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="flush-headingSeven">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseSeven" aria-expanded="false" aria-controls="flush-collapseSeven">
                                        <div className='sidebar-main-title'>
                                            <div className='sidebar-icon'><BiSolidContact className='icon' /></div>
                                            <div className='sidebar-title'>Contacts</div>
                                        </div>
                                        <div className='sidebar-right-icon'>
                                            <MdKeyboardArrowRight className='arrow-icon' />
                                        </div>
                                    </button>
                                </h2>
                                <div id="flush-collapseSeven" class="accordion-collapse collapse" aria-labelledby="flush-headingSeven" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body accordion-body-content">
                                        <ul>
                                            <li><Link to='/parties'><LuDot className='dot-icon' /><span>Parties</span></Link></li>
                                            <li><Link to='/brokers'><LuDot className='dot-icon' /><span>Blokers</span></Link></li>

                                        </ul>

                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="flush-headingEight">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseEight" aria-expanded="false" aria-controls="flush-collapseEight">
                                        <div className='sidebar-main-title'>
                                            <div className='sidebar-icon'><FaLayerGroup className='icon' /></div>
                                            <div className='sidebar-title'>Manage Products</div>
                                        </div>
                                        <div className='sidebar-right-icon'>
                                            <MdKeyboardArrowRight className='arrow-icon' />
                                        </div>
                                    </button>
                                </h2>
                                <div id="flush-collapseEight" class="accordion-collapse collapse" aria-labelledby="flush-headingEight" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body accordion-body-content">
                                        <ul>
                                            <li><Link to='/brand'><LuDot className='dot-icon' /><span>Brand</span></Link></li>
                                            <li><Link to='/product'><LuDot className='dot-icon' /><span>Products</span></Link></li>
                                            <li><Link to='/size'><LuDot className='dot-icon' /><span>Sizes</span></Link></li>

                                        </ul>

                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="flush-headingEight1">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseEight1" aria-expanded="false" aria-controls="flush-collapseEight1">
                                        <div className='sidebar-main-title'>
                                            <div className='sidebar-icon'><GiUpgrade className='icon' /></div>
                                            <div className='sidebar-title'>Manage Grades</div>
                                        </div>
                                        <div className='sidebar-right-icon'>
                                            <MdKeyboardArrowRight className='arrow-icon' />
                                        </div>
                                    </button>
                                </h2>
                                <div id="flush-collapseEight1" class="accordion-collapse collapse" aria-labelledby="flush-headingEight1" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body accordion-body-content">
                                        <ul>
                                            <li><Link to='/grades'><LuDot className='dot-icon' /><span>Grades</span></Link></li>
                                        </ul>

                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="flush-heading2">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse2" aria-expanded="false" aria-controls="flush-collapse2">
                                        <Link to="/all-vehicles">
                                            <div className='sidebar-main-title'>
                                                <div className='sidebar-icon'><FaTruck className='icon' /></div>
                                                <div className='sidebar-title'>All Vehicles</div>
                                            </div>
                                        </Link>

                                    </button>
                                </h2>

                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="flush-heading3">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse3" aria-expanded="false" aria-controls="flush-collapse3">
                                        <Link to="/all-users">
                                            <div className='sidebar-main-title'>
                                                <div className='sidebar-icon'><FaUsers className='icon' /></div>
                                                <div className='sidebar-title'>ERP Users</div>
                                            </div>
                                        </Link>

                                    </button>
                                </h2>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="flush-heading4">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse4" aria-expanded="false" aria-controls="flush-collapse4">
                                        <Link to="/ip-list">
                                            <div className='sidebar-main-title'>
                                                <div className='sidebar-icon'><FaWifi className='icon' /></div>
                                                <div className='sidebar-title'>Allowed IP</div>
                                            </div>
                                        </Link>

                                    </button>
                                </h2>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="flush-heading5">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse5" aria-expanded="false" aria-controls="flush-collapse5">
                                        <Link to="/">
                                            <div className='sidebar-main-title'>
                                                <div className='sidebar-icon'><IoMdLogOut className='icon' /></div>
                                                <div className='sidebar-title'>Logout</div>
                                            </div>
                                        </Link>

                                    </button>
                                </h2>
                            </div>

                        </div>
                    </div>
                </div>
            </div>


        </>
    )
}

export default Sidebar