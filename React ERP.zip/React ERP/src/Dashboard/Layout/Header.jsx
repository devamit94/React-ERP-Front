import React from 'react'
import { FaBars, FaTruck, FaUser } from 'react-icons/fa';
import logo from '../../Assets/img/logo.png'
import userIcon from '../../Assets/img/user-1.jpg'
import { Link } from 'react-router-dom';
import { IoMdLogOut } from 'react-icons/io';


const Header = ({ toggle, TOS }) => {
    return (
        <>
            {/* <section id="header" className={`header-main   ${TOS ? 'new_header' : ''} `}> */}
            <section id="header" className='header-main'>
                <div className='container-fluid'>
                    <div className='h-inner-row'>

                        <div className='h-column-left'>
                            <div className='logo'>
                                <img src={logo} alt='logo-image' />
                            </div>
                            <button type="button" className='btn toggle-btn' onClick={toggle}>
                                <span><FaBars className='icon'/></span>
                            </button>
                        </div>
                        <div className='h-column-right'>
                            <div class="dropdown">
                                <button class="btn dropdown-btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <img src={userIcon} alt="user-btn-image" className='user-image' />
                                </button>
                                <ul class="dropdown-menu dropdown-body">
                                    <li><Link to=''><FaTruck className="icon"/><span>Job Work</span></Link></li>
                                    <li><Link to=''><FaUser className="icon"/><span>My Profile</span></Link></li>
                                    <li className='text-center mt-2'><button className='btn logout-btn'><IoMdLogOut className='icon' />Logout</button></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default Header